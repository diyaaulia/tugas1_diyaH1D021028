# tugas-1

Lengkapilah method perkenalan() pada class Mahasiswa sehingga bisa menampilkan output sebagai berikut

Perkenalkan, nama saya `nama` dengan NIM `nim` dan usia saya `usia` tahun.

Clue: Untuk mengetahui tahun saat ini, gunakan `DateTime.now().year`

Buatlah objek sesuai dengan data diri masing-masing dan panggil method perkenalan di dalam fungsi main().
